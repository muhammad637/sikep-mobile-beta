import 'package:flutter/material.dart';
import 'package:flutter_testing/providers/auth_provider.dart';
import 'package:provider/provider.dart';
import '../../models/product.dart';
import '../../models/user.dart';
import '../../providers/product_provider.dart';

class DashboardPage extends StatelessWidget {
  @override
  // void initState() {
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    Provider.of<ProductProvider>(context, listen: false).fetchProducts();
    List<Product> products = Provider.of<ProductProvider>(context).products;
    // ignore: unused_local_variable
    User? user = Provider.of<AuthProvider>(context).user;

    return Scaffold(
        appBar: AppBar(
          title: Text('Dashboard'),
        ),
        body: 
        (products.isNotEmpty)
                  ? ListView.builder(
                      itemCount: products.length,
                      itemBuilder: (context, index) => ListTile(
                        title: Text(products[index].nama),
                        subtitle: Text(products[index].harga.toString()),
                      ),
                    )
                  // ignore: avoid_unnecessary_containers
                  : Container(
                      child: const Text('kosong'),
                    ),
        // Container(
        //   child: 
        //   Column(
        //     children: [
        //       Text('halo ${user!.name}'),
              
        //     ],
        //   ),
        // )
       
        );
  }
}
