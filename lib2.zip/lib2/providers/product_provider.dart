import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/service.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  // int? _jumlahProducts;
  final ApiService _apiService = ApiService();

  List<Product> get products => _products;
  Product? _product;
  get product => _product;
  
  // Future<void> 

  Future<void> fetchProducts() async {
    try {
      _products = await _apiService.fetchProducts();
      notifyListeners();
    } catch (e) {
      print('Error fetching products: $e');
    }
  }
}
