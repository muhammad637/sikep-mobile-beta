class Product {
  final String id;
  final String nama;
  final String harga;
  final String jumlah;

  Product(
      {required this.id,
      required this.nama,
      required this.harga,
      required this.jumlah});

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'].toString(),
      nama: json['nama'].toString(),
      harga: json['harga'].toString(),
      jumlah: json['jumlah'].toString(),
    );
  }
}
