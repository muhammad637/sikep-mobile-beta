import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import '../models/product.dart';

class ApiService {
  static const String baseUrl = 'http://192.168.238.205:8000/api/';
  

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response =
        await http.post(Uri.parse(baseUrl + 'login'), headers: <String, String>{
      'Accept': 'application/json'
    }, body: {
      'email': email,
      'password': password,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to login');
    }
  }

  Future<List<Product>> fetchProducts() async {
    String token = await getToken();
   
    final response = await http.get(
        Uri.parse(baseUrl + 'testing'),
        headers: <String, String>{'Accept': 'application/json',
        'Authorization': 'Bearer $token'
      },
        );

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body)['data'];
      return data.map((item) => Product.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<String> getToken() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('authToken') ?? '';
  }
}
