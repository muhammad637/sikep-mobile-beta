import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../pages/dashboard.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AuthProvider authProvider = Provider.of<AuthProvider>(context);
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await authProvider.login('major45@example.org',
                'password'); // ganti email dan password pada method login sesuai dengan input pengguna
                print(authProvider.user!.name);
            // ignore: use_build_context_synchronously
            Navigator.pushReplacementNamed(context, '/dashboard');
          },
          child: Text('Login'),
        ),
      ),
    );
  }
}
