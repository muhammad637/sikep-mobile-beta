class User {
  final String id;
  final String name;
  final String email;
  final String role;
  final String token;

  User(
      {required this.id,
      required this.name,
      required this.email,
      required this.token,
      required this.role});

  factory User.fromJson(Map<dynamic, dynamic> json) {
    return User(
      id: json['data']['id'].toString(),
      name: json['data']['name'].toString(),
      role: json['data']['role'].toString(),
      email: json['data']['email'].toString(),
      token: json['token'].toString(),
    );
  }
}
