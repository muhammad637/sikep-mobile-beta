import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';
import '../services/service.dart';

enum AuthStatus { authenticated, unauthenticated, loading, error }

class AuthProvider with ChangeNotifier {
  AuthStatus _status = AuthStatus.unauthenticated;
  User? _user;

  AuthStatus get status => _status;
  User? get user => _user;
  String? testing;

  final ApiService _apiService = ApiService();

  Future<void> login(String email, String password) async {
    try {
      _status = AuthStatus.loading;
      notifyListeners();

      Map<dynamic, dynamic> userData = await _apiService.login(email, password);

      // Extract token here from the response data
      String token =
          userData['token']; // Adjust this based on your API response structure

      // Simpan token di sini, contoh menggunakan SharedPreferences
      // Pastikan untuk menggunakan bibliotek yang aman untuk menyimpan token
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString('authToken', token);
      testing = "testing";

      // Setelah token berhasil disimpan, update ke status autentikasi berhasil
      _user = User.fromJson(userData);
      // _status = AuthStatus.authenticated;
      // prefs.getString('authToken');
      notifyListeners();
    } catch (e) {
      _status = AuthStatus.error;
      testing = "error ${e.toString()}";
      notifyListeners();
    }
  }

  

  void logout() async {
    // Remove the token from storage
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('authToken');

    // Reset state to unauthenticated
    _user = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}
